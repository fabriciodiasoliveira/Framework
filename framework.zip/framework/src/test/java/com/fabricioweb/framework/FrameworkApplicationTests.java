package com.fabricioweb.framework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrameworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
